from selenium import webdriver
from selenium.webdriver.common.by import By

from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select
from datetime import datetime, timedelta

import pytest
from core.models import Colaborador, Equipamento

@pytest.mark.django_db
def test_cadastrar_colaborador(live_server):
    """Teste Selenium que usa o servidor de teste provido por pytest-django.

    O fixture `live_server` inicia um servidor com a aplicação e expõe a URL
    em `live_server.url`, evitando erro de conexão quando o servidor não está
    rodando manualmente.
    """
    driver = webdriver.Chrome()

    # criar instâncias necessárias no banco para os ModelChoiceFields ANTES de carregar a página
    col = Colaborador.objects.create(nome="Guilherme", matricula="123", cargo="Dev")
    eq = Equipamento.objects.create(nome="219-52", codigo="219-52", descricao="teste", quantidade_total=1)

    # usar a URL do servidor de teste em vez de um host hardcoded
    # navegar para a página de criação de EPI
    driver.get(live_server.url + '/epi/novo/')

    wait = WebDriverWait(driver, 15)
    colaborador_select = wait.until(EC.presence_of_element_located((By.NAME, "colaborador")))
    equipamento_select = driver.find_element(By.NAME, "equipamento")
    # esperar que as opções apareçam (os option são renderizados no servidor)
    wait.until(lambda d: d.find_elements(By.CSS_SELECTOR, "select[name='colaborador'] option[value]") and d.find_elements(By.CSS_SELECTOR, "select[name='equipamento'] option[value]"))
    data_entrega_input = driver.find_element(By.NAME, "data_entrega")
    data_prevista_devolucao_input = driver.find_element(By.NAME, "data_prevista_devolucao")
    status_input = driver.find_element(By.NAME, "status")
    observacao_input = driver.find_element(By.NAME, "observacao")
    submit_button = driver.find_element(By.XPATH, "//button[@type='submit']")

    # preencher o formulário
    # selecionar as opções pelos valores (pks) usando Select quando aplicável
    try:
        Select(colaborador_select).select_by_value(str(col.pk))
    except Exception:
        driver.execute_script("arguments[0].value = arguments[1]; arguments[0].dispatchEvent(new Event('change'))", colaborador_select, str(col.pk))
    try:
        Select(equipamento_select).select_by_value(str(eq.pk))
    except Exception:
        driver.execute_script("arguments[0].value = arguments[1]; arguments[0].dispatchEvent(new Event('change'))", equipamento_select, str(eq.pk))

    # inputs do tipo datetime-local exigem formato ISO: YYYY-MM-DDTHH:MM
    # usar datas futuras para passar validações de formulário
    data_entrega_input.clear()
    data_prevista_devolucao_input.clear()
    # usar datas futuras dinamicamente para passar validações de formulário
    now = datetime.now()
    dt_ent = (now + timedelta(days=2)).strftime('%Y-%m-%dT%H:%M')
    dt_prev = (now + timedelta(days=5)).strftime('%Y-%m-%dT%H:%M')
    # definir via JS com segundos e disparar eventos para garantir que o valor será submetido corretamente
    dt_ent_s = dt_ent + ':00' if len(dt_ent.split(':')) == 2 else dt_ent
    dt_prev_s = dt_prev + ':00' if len(dt_prev.split(':')) == 2 else dt_prev
    driver.execute_script("arguments[0].value = arguments[1]; arguments[0].dispatchEvent(new Event('input')); arguments[0].dispatchEvent(new Event('change'));", data_entrega_input, dt_ent_s)
    driver.execute_script("arguments[0].value = arguments[1]; arguments[0].dispatchEvent(new Event('input')); arguments[0].dispatchEvent(new Event('change'));", data_prevista_devolucao_input, dt_prev_s)

    # status é um select com valores em maiúsculas (ver EPIStatus)
    try:
        Select(status_input).select_by_value('EM_USO')
        driver.execute_script("arguments[0].dispatchEvent(new Event('change'))", status_input)
    except Exception:
        status_input.send_keys('EM_USO')
        driver.execute_script("arguments[0].dispatchEvent(new Event('change'))", status_input)

    observacao_input.send_keys("novo")

    submit_button.click()

    # Aguardar a mensagem de sucesso (bootstrap .alert)
    try:
        # esperar por alerta de mensagem OR por mensagens de erro inline nos campos
        success_or_error = wait.until(EC.any_of(
            EC.visibility_of_element_located((By.CSS_SELECTOR, ".alert")),
            EC.presence_of_element_located((By.CSS_SELECTOR, ".text-danger.small"))
        ))
        # se for alerta, verificar sucesso
        alerts = driver.find_elements(By.CSS_SELECTOR, ".alert")
        if alerts:
            success_alert = alerts[0].text
            if "Registro de EPI cadastrado com sucesso" in success_alert or "cadastrado com sucesso" in success_alert:
                print("Resultado: Cadastrado EPI com sucesso via Selenium.")
            else:
                # houve falha geral — coletar erros inline e falhar com detalhe
                errors = [e.text for e in driver.find_elements(By.CSS_SELECTOR, ".text-danger.small")]
                raise AssertionError(f"Alerta de falha: {success_alert}; erros inline: {errors}")
        else:
            # há erros inline nos campos — falha no cadastro
            errors = [e.text for e in driver.find_elements(By.CSS_SELECTOR, ".text-danger.small")]
            raise AssertionError(f"Erros de validação no formulário: {errors}")
    except Exception as e:
        # salvar artefatos para debugging
        try:
            driver.save_screenshot('selenium_failure_screenshot.png')
            with open('selenium_failure_page.html','w', encoding='utf-8') as f:
                f.write(driver.page_source)
        except Exception:
            pass
        raise
    finally:
        driver.quit()
