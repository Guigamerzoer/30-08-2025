from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

import pytest
import shutil
import time


# Skip tests if selenium or chrome not available
try:
    import selenium  # noqa: F401
    HAS_SELENIUM = True
except Exception:
    HAS_SELENIUM = False

chrome_path = shutil.which('chrome') or shutil.which('chrome.exe') or shutil.which('chromium') or shutil.which('chromium.exe') or shutil.which('msedge')
HAS_CHROME = bool(chrome_path)


@pytest.mark.skipif(not (HAS_SELENIUM and HAS_CHROME), reason="selenium or chrome not available")
@pytest.mark.django_db
def test_create_colaborador_via_ui(live_server):
    options = Options()
    options.add_argument('--headless=new')
    options.add_argument('--no-sandbox')
    options.add_argument('--disable-gpu')

    service = ChromeService(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=options)

    try:
        uniq = str(int(time.time() * 1000))[-6:]
        nome = f"Test Colab {uniq}"

        driver.get(f"{live_server.url}/colaboradores/novo/")
        form = driver.find_element(By.TAG_NAME, 'form')

        # Fill first text input available
        inputs = form.find_elements(By.TAG_NAME, 'input')
        text_inputs = [i for i in inputs if (i.get_attribute('type') or 'text') in ('text', 'string')]
        if text_inputs:
            text_inputs[0].clear()
            text_inputs[0].send_keys(nome)
        else:
            ta = form.find_elements(By.TAG_NAME, 'textarea')
            if ta:
                ta[0].send_keys(nome)

        # Submit form via JS to avoid click interception
        driver.execute_script("arguments[0].submit();", form)

        wait = WebDriverWait(driver, 10)
        wait.until(EC.url_contains('/colaboradores'))

        xpath = f"//td[contains(., '{nome}')]"
        found = wait.until(EC.presence_of_element_located((By.XPATH, xpath)))
        assert nome in found.text

    finally:
        driver.quit()


@pytest.mark.skipif(not (HAS_SELENIUM and HAS_CHROME), reason="selenium or chrome not available")
@pytest.mark.django_db
def test_create_colaborador_and_see_edit(live_server):
    options = Options()
    options.add_argument('--headless=new')
    options.add_argument('--no-sandbox')
    options.add_argument('--disable-gpu')

    service = ChromeService(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=options)

    try:
        uniq = str(int(time.time() * 1000))[-6:]
        nome = f"Colab Edit {uniq}"

        driver.get(f"{live_server.url}/colaboradores/novo/")
        form = driver.find_element(By.TAG_NAME, 'form')

        inputs = form.find_elements(By.TAG_NAME, 'input')
        if inputs:
            text_inputs = [i for i in inputs if (i.get_attribute('type') or 'text') in ('text', 'string')]
            if text_inputs:
                text_inputs[0].send_keys(nome)
            else:
                inputs[0].send_keys(nome)
        else:
            ta = form.find_elements(By.TAG_NAME, 'textarea')
            if ta:
                ta[0].send_keys(nome)

        driver.execute_script("arguments[0].submit();", form)

        wait = WebDriverWait(driver, 10)
        wait.until(EC.url_contains('/colaboradores'))

        xpath_row = f"//td[contains(., '{nome}')]/.."
        row = wait.until(EC.presence_of_element_located((By.XPATH, xpath_row)))
        edit_btn = row.find_element(By.XPATH, ".//a[contains(., 'Editar') or contains(., 'editar')]")
        assert edit_btn is not None

    finally:
        driver.quit()
