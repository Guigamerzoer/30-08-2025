from selenium import webdriver
from selenium.webdriver.common.by import By

from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

import pytest

@pytest.mark.django_db
def test_cadastrar_colaborador():
    driver = webdriver.Chrome()
    driver.get("http://127.0.0.1:8000/colaboradores/novo/")
    nome_input = driver.find_element(By.NAME, "nome")
    matricula_input = driver.find_element(By.NAME, "matricula")
    cargo_input = driver.find_element(By.NAME, "cargo")
    submit_button = driver.find_element(By.XPATH, "/html/body/main/div/form/div[4]/button")

    nome_input.send_keys("Guilherme")
    import time
    time.sleep(2)
    matricula_input.send_keys("093.805.219-52")
    time.sleep(2)
    cargo_input.send_keys("Tecnico")
    time.sleep(2)
    

    submit_button.click()

    # Aguardar o modal aparecer
    wait = WebDriverWait(driver, 10)
    alert_message = wait.until(EC.visibility_of_element_located((By.XPATH, "/html/body/main/div[1]/div"))).text

    assert "Colaborador cadastrado com sucesso!" in alert_message

    print("Resultado: Colaborador cadastrado com sucesso via Selenium.")

    driver.quit()
