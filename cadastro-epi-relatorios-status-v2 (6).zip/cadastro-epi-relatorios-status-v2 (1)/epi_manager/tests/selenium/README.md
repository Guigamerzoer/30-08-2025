Instruções rápidas para rodar os testes Selenium (Windows PowerShell):

1) Instale dependências (recomendo ambiente virtual):

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

2) Rode os testes Selenium a partir da pasta `epi_manager` (onde está `manage.py`):

```powershell
cd epi_manager
pytest tests/selenium -q
```

Observações:
- Os testes usam `webdriver-manager` para baixar o ChromeDriver automaticamente.
- No Windows, se ocorrer erro de execução do Chrome em headless, remova `--headless=new` e tente sem headless para depurar.
- Se preferir usar Firefox, ajuste o teste para usar geckodriver e webdriver-manager para Firefox.
