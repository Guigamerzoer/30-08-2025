from selenium import webdriver
from selenium.webdriver.common.by import By

from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

import pytest

@pytest.mark.django_db
def test_cadastrar_colaborador(live_server):
    driver = webdriver.Chrome()
    try:
        driver.get(live_server.url + "/equipamentos/novo/")
        nome_input = driver.find_element(By.NAME, "nome")
        codigo_input = driver.find_element(By.NAME, "codigo")
        descricao_input = driver.find_element(By.NAME, "descricao")
        # o campo no form é 'quantidade_total'
        quantidade_input = driver.find_element(By.NAME, "quantidade_total")
        # botão submit - localizar pelo tipo
        submit_button = driver.find_element(By.CSS_SELECTOR, "button[type='submit']")

        nome_input.send_keys("Guilherme")
        import time
        time.sleep(2)
        codigo_input.send_keys("219-52")
        time.sleep(2)
        descricao_input.send_keys("Novo")
        time.sleep(2)
        quantidade_input.send_keys("1")
        time.sleep(2)

        submit_button.click()

        wait = WebDriverWait(driver, 10)
        alert = wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, ".alert-success")))
        alert_message = alert.text
        assert "Equipamento cadastrado com sucesso" in alert_message or "sucesso" in alert_message.lower()
        print("Resultado: Equipamento cadastrado com sucesso via Selenium.")
    finally:
        driver.quit()
