import pytest
from django.urls import reverse
from django.test import Client
from core.models import Equipamento

@pytest.mark.django_db
def test_integracao_equipamento_update():
    equip = Equipamento.objects.create(nome="EquipUpdate", codigo="EQUPD01", descricao="desc", quantidade_total=1)
    client = Client()
    url_update = reverse('core:equipamentos_update', args=[equip.id])
    data = {"nome": "Equip Atualizado", "codigo": "EQUPD01", "descricao": "desc", "quantidade_total": 2}
    response = client.post(url_update, data)
    equip.refresh_from_db()
    assert equip.nome == "Equip Atualizado"
    assert equip.quantidade_total == 2
    assert response.status_code == 302

@pytest.mark.django_db
def test_integracao_equipamento_delete():
    equip = Equipamento.objects.create(nome="EquipDelete", codigo="EQDEL01", descricao="desc", quantidade_total=1)
    client = Client()
    url_delete = reverse('core:equipamentos_delete', args=[equip.id])
    response = client.post(url_delete)
    assert response.status_code == 302
    assert not Equipamento.objects.filter(id=equip.id).exists()
