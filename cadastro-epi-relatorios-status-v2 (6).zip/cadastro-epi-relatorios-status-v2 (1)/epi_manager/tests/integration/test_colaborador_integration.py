import pytest
from django.urls import reverse
from django.test import Client
from core.models import Colaborador

@pytest.mark.django_db
def test_integracao_colaborador_criar_listar():
    client = Client()
    url_create = reverse('core:colaboradores_create')
    url_list = reverse('core:colaboradores_list')
    data = {"nome": "IntegracaoColab", "matricula": "INTCOLAB01"}
    client.post(url_create, data)
    response = client.get(url_list)
    assert b"IntegracaoColab" in response.content
