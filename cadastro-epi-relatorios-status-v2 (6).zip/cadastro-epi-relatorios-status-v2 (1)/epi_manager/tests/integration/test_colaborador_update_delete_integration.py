import pytest
from django.urls import reverse
from django.test import Client
from core.models import Colaborador

@pytest.mark.django_db
def test_integracao_colaborador_update():
    colab = Colaborador.objects.create(nome="Update User", matricula="UPD01")
    client = Client()
    url_update = reverse('core:colaboradores_update', args=[colab.id])
    data = {"nome": "User Atualizado", "matricula": "UPD01"}
    response = client.post(url_update, data)
    colab.refresh_from_db()
    assert colab.nome == "User Atualizado"
    assert response.status_code == 302

@pytest.mark.django_db
def test_integracao_colaborador_delete():
    colab = Colaborador.objects.create(nome="Delete User", matricula="DEL01")
    client = Client()
    url_delete = reverse('core:colaboradores_delete', args=[colab.id])
    response = client.post(url_delete)
    assert response.status_code == 302
    assert not Colaborador.objects.filter(id=colab.id).exists()
