import pytest
from core.models import Colaborador, Equipamento, EPIControle, EPIStatus
from django.utils import timezone
from datetime import timedelta

@pytest.mark.django_db
def test_integracao_emprestimo_e_devolucao():
    colaborador = Colaborador.objects.create(nome="Lucas", matricula="202")
    equipamento = Equipamento.objects.create(nome="Cinto", codigo="EPI005")
    data_prevista = timezone.now() + timedelta(days=3)
    emprestimo = EPIControle.objects.create(colaborador=colaborador, equipamento=equipamento, data_prevista_devolucao=data_prevista)
    # Simula devolução
    emprestimo.status = EPIStatus.DEVOLVIDO
    emprestimo.data_devolucao = timezone.now()
    emprestimo.save()
    assert emprestimo.status == EPIStatus.DEVOLVIDO
    assert emprestimo.data_devolucao is not None
