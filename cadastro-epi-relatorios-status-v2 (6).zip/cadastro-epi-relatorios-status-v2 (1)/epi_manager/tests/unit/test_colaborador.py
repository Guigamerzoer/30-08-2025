import pytest
from core.models import Colaborador

@pytest.mark.django_db
def test_criar_colaborador():
    colaborador = Colaborador.objects.create(nome="João", matricula="123", cargo="Técnico")
    assert colaborador.nome == "João"
    assert colaborador.matricula == "123"

@pytest.mark.django_db
def test_str_colaborador():
    colaborador = Colaborador.objects.create(nome="Maria", matricula="456")
    assert str(colaborador) == "Maria (matrícula: 456)"
