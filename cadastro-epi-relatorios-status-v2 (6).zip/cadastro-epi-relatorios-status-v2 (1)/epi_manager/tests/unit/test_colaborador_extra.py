import pytest
from core.models import Colaborador

@pytest.mark.django_db
def test_colaborador_cargo_vazio():
    colaborador = Colaborador.objects.create(nome="Sem Cargo", matricula="000")
    assert colaborador.cargo == ""

@pytest.mark.django_db
def test_colaborador_matricula_unica():
    Colaborador.objects.create(nome="A", matricula="X")
    with pytest.raises(Exception):
        Colaborador.objects.create(nome="B", matricula="X")
