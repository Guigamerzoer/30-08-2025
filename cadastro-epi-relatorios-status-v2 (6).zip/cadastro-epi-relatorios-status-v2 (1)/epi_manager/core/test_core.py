import pytest
from core.models import Colaborador, Equipamento, EPIControle, EPIStatus
from django.utils import timezone
from datetime import timedelta

@pytest.mark.django_db
def test_criar_colaborador():
    colaborador = Colaborador.objects.create(nome="João", matricula="123", cargo="Técnico")
    assert colaborador.nome == "João"
    assert colaborador.matricula == "123"

@pytest.mark.django_db
def test_str_colaborador():
    colaborador = Colaborador.objects.create(nome="Maria", matricula="456")
    assert str(colaborador) == "Maria (matrícula: 456)"

@pytest.mark.django_db
def test_criar_equipamento():
    equipamento = Equipamento.objects.create(nome="Capacete", codigo="EPI001", descricao="Capacete de segurança", quantidade_total=10)
    assert equipamento.nome == "Capacete"
    assert equipamento.codigo == "EPI001"

@pytest.mark.django_db
def test_str_equipamento():
    equipamento = Equipamento.objects.create(nome="Luva", codigo="EPI002")
    assert str(equipamento) == "Luva (cód: EPI002)"

@pytest.mark.django_db
def test_criar_emprestimo():
    colaborador = Colaborador.objects.create(nome="Carlos", matricula="789")
    equipamento = Equipamento.objects.create(nome="Óculos", codigo="EPI003")
    data_prevista = timezone.now() + timedelta(days=7)
    emprestimo = EPIControle.objects.create(colaborador=colaborador, equipamento=equipamento, data_prevista_devolucao=data_prevista)
    assert emprestimo.status == EPIStatus.EMPRESTADO
    assert emprestimo.colaborador == colaborador

@pytest.mark.django_db
def test_str_emprestimo():
    colaborador = Colaborador.objects.create(nome="Ana", matricula="101")
    equipamento = Equipamento.objects.create(nome="Protetor", codigo="EPI004")
    data_prevista = timezone.now() + timedelta(days=5)
    emprestimo = EPIControle.objects.create(colaborador=colaborador, equipamento=equipamento, data_prevista_devolucao=data_prevista)
    assert str(emprestimo) == f"{equipamento} -> {colaborador} [{emprestimo.status}]"

@pytest.mark.django_db
def test_integracao_emprestimo_e_devolucao():
    colaborador = Colaborador.objects.create(nome="Lucas", matricula="202")
    equipamento = Equipamento.objects.create(nome="Cinto", codigo="EPI005")
    data_prevista = timezone.now() + timedelta(days=3)
    emprestimo = EPIControle.objects.create(colaborador=colaborador, equipamento=equipamento, data_prevista_devolucao=data_prevista)
    # Simula devolução
    emprestimo.status = EPIStatus.DEVOLVIDO
    emprestimo.data_devolucao = timezone.now()
    emprestimo.save()
    assert emprestimo.status == EPIStatus.DEVOLVIDO
    assert emprestimo.data_devolucao is not None
