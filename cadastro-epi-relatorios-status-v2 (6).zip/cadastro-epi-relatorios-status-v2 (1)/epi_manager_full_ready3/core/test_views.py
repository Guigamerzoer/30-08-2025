import pytest
from django.urls import reverse
from django.test import Client
from core.models import Colaborador, Equipamento

@pytest.mark.django_db
def test_colaboradores_list_view():
    Colaborador.objects.create(nome="Teste", matricula="001")
    client = Client()
    url = reverse('core:colaboradores_list')
    response = client.get(url)
    assert response.status_code == 200
    assert b"Teste" in response.content

@pytest.mark.django_db
def test_equipamentos_list_view():
    Equipamento.objects.create(nome="Capacete", codigo="E001")
    client = Client()
    url = reverse('core:equipamentos_list')
    response = client.get(url)
    assert response.status_code == 200
    assert b"Capacete" in response.content

@pytest.mark.django_db
def test_colaboradores_create_view():
    client = Client()
    url = reverse('core:colaboradores_create')
    data = {"nome": "Novo", "matricula": "999"}
    response = client.post(url, data)
    assert response.status_code == 302  # redirect após sucesso
    assert Colaborador.objects.filter(matricula="999").exists()

@pytest.mark.django_db
def test_equipamentos_create_view():
    client = Client()
    url = reverse('core:equipamentos_create')
    data = {"nome": "Luva", "codigo": "E002"}
    response = client.post(url, data)
    assert response.status_code == 302
    assert Equipamento.objects.filter(codigo="E002").exists()

@pytest.mark.django_db
def test_integracao_criar_listar_colaborador():
    client = Client()
    url_create = reverse('core:colaboradores_create')
    url_list = reverse('core:colaboradores_list')
    data = {"nome": "Integracao", "matricula": "888"}
    client.post(url_create, data)
    response = client.get(url_list)
    assert b"Integracao" in response.content
