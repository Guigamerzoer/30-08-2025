const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const sequelize = require('./database');
const colaboradorRoutes = require('./routes/colaboradorRoutes');

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.use('/colaboradores', colaboradorRoutes);

// Sincronizar banco e iniciar servidor
sequelize.sync().then(() => {
  app.listen(3000, () => console.log('Servidor rodando na porta 3000'));
});
