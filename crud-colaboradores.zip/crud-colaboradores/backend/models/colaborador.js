const { DataTypes } = require('sequelize');
const sequelize = require('../database');

const Colaborador = sequelize.define('Colaborador', {
  nome: { type: DataTypes.STRING, allowNull: false },
  email: { type: DataTypes.STRING, allowNull: false, unique: true },
  cargo: { type: DataTypes.STRING, allowNull: false },
  telefone: { type: DataTypes.STRING }
});

module.exports = Colaborador;
