const express = require('express');
const router = express.Router();
const Colaborador = require('../models/colaborador');  // Ajuste o caminho conforme sua estrutura

// Criar novo colaborador
router.post('/', async (req, res) => {
  try {
    const colaborador = await Colaborador.create(req.body);
    res.status(201).json(colaborador);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao criar colaborador' });
  }
});

// Listar todos os colaboradores
router.get('/', async (req, res) => {
  try {
    const colaboradores = await Colaborador.findAll();
    res.status(200).json(colaboradores);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao listar colaboradores' });
  }
});

// Atualizar colaborador
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    await Colaborador.update(req.body, { where: { id } });
    res.status(200).json({ message: 'Colaborador atualizado com sucesso' });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao atualizar colaborador' });
  }
});

// Excluir colaborador
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    await Colaborador.destroy({ where: { id } });
    res.status(200).json({ message: 'Colaborador excluído com sucesso' });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao excluir colaborador' });
  }
});

module.exports = router;
